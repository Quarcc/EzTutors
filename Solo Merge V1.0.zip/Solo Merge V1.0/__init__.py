from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, send_file, session, g
from Forms import CreateStudentAccount, LoginAccount, CreateTutorAccount, CreateNotifications, CreateFeedback, CreateTestQuestion, CreateRevisionQuestion, StudentTestQuestion, StudentRevisionQuestion, CreateAnnouncementForm
import shelve, Notification, Feedback, STEST, SREVISION, Test, Revision, announce, os, pickle
from Feedback import Feedback
from announce import Announcement
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import inspect
from werkzeug.utils import secure_filename
import uuid as uuid

# ----------------- WEE JUN CAI, BRANDON ----------------
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///eztutors.db'
app.config['SQLALCHEMY_TRACK_NOTIFICATIONS'] = False
app.config['SQLALCHEMY_SILENCE_UBER_WARNING'] = True
app.secret_key = os.urandom(24)  # generate a random secret key
db = SQLAlchemy(app)
with app.app_context():
    inspector = inspect(db.engine)


class Student(db.Model):
    student_id_num = db.Column("id_num", db.String(7), primary_key=True)
    student_first_name = db.Column("first_name", db.String(80))
    student_last_name = db.Column("last_name", db.String(80))
    student_password = db.Column("password", db.String(127))
    student_mobile = db.Column("mobile", db.String(8))
    student_email = db.Column("email", db.String(150))
    student_education_level = db.Column("education level", db.String)
    student_class = db.Column("student class(es)", db.String)
    student_img = db.Column("student profile picture", db.String)

    def __init__(self, student_id_num, student_first_name, student_last_name, student_password, student_mobile, student_email, student_education_level, student_class, student_img):
        self.student_id_num = student_id_num
        self.student_first_name = student_first_name
        self.student_last_name = student_last_name
        self.student_password = student_password
        self.student_mobile = student_mobile
        self.student_email = student_email
        self.student_education_level = student_education_level
        self.student_class = student_class
        self.student_img = student_img


class Tutor(db.Model):

    tutor_id_num = db.Column("id_num", db.String(7), primary_key=True)
    tutor_first_name = db.Column("first_name", db.String(80))
    tutor_last_name = db.Column("last_name", db.String(80))
    tutor_password = db.Column("password", db.String(127))
    tutor_age = db.Column("age", db.String(2))
    tutor_mobile = db.Column("mobile", db.String(8))
    tutor_email = db.Column("email", db.String(150))
    tutor_teaching_level = db.Column("teaching level", db.String)
    tutor_class = db.Column("tutor class(es)", db.String)
    tutor_img = db.Column("tutor profile picture", db.String)

    def __init__(self, tutor_id_num, tutor_first_name, tutor_last_name, tutor_password, tutor_age, tutor_mobile, tutor_email, tutor_teaching_level, tutor_class, tutor_img):
        self.tutor_id_num = tutor_id_num
        self.tutor_first_name = tutor_first_name
        self.tutor_last_name = tutor_last_name
        self.tutor_password = tutor_password
        self.tutor_age = tutor_age
        self.tutor_mobile = tutor_mobile
        self.tutor_email = tutor_email
        self.tutor_teaching_level = tutor_teaching_level
        self.tutor_class = tutor_class
        self.tutor_img = tutor_img


class Admin(db.Model):
    admin_id_num = db.Column("id_num", db.String(7), primary_key=True)
    admin_first_name = db.Column("first_name", db.String(80))
    admin_last_name = db.Column("last_name", db.String(80))
    admin_password = db.Column("password", db.String(127))
    admin_mobile = db.Column("mobile", db.Integer)
    admin_email = db.Column("email", db.String(150))

    def __init__(self, admin_id_num, admin_first_name, admin_last_name, admin_password, admin_mobile, admin_email):
        self.admin_id_num = admin_id_num
        self.admin_first_name = admin_first_name
        self.admin_last_name = admin_last_name
        self.admin_password = admin_password
        self.admin_mobile = admin_mobile
        self.admin_email = admin_email


def save_image(img_file):
    image_name = str(uuid.uuid1()) + "_" + secure_filename(img_file.filename)
    image_path = os.path.join(app.root_path, 'static/profile_pics', image_name)
    img_file.save(image_path)
    return image_name


@app.before_request
def before_request():
    g.user = None

    if 'user' in session:
        g.user = session['user']


@app.route('/main')
def main():
    return render_template('main.html')


@app.route('/studentlogin', methods=['POST', 'GET'])
def student_login():
    student_login_form = LoginAccount(request.form)
    if request.method == 'POST' and student_login_form.validate():
        session.pop('user', None)

    student_account = Student.query.all()

    for i in student_account:
        student_id = i.student_id_num
        if student_id == student_login_form.id_num.data:
            student_info = Student.query.filter_by(student_id_num=student_login_form.id_num.data).first()
            student_pass = student_info.student_password

            if student_pass == student_login_form.password.data:
                session['user'] = student_login_form.id_num.data

                return redirect(url_for('tutor_retrieve_content'))

    return render_template('studentlogin.html')


@app.route('/tutorlogin', methods=['POST', 'GET'])
def tutor_login():
    tutor_login_form = LoginAccount(request.form)
    if request.method == 'POST' and tutor_login_form.validate():
        session.pop('user', None)

    if not inspector.has_table("tutor"):
        admin_account = Admin.query.all()
        for i in admin_account:
            admin_id = i.admin_id_num
            if admin_id == tutor_login_form.id_num.data:
                admin_info = Admin.query.filter_by(admin_id_num=tutor_login_form.id_num.data).first()
                admin_pass = admin_info.admin_password

                if admin_pass == tutor_login_form.password.data:
                    session['user'] = tutor_login_form.id_num.data

                    return redirect(url_for('tutor_retrieve_content'))
    else:
        admin_account = Admin.query.all()
        tutor_account = Tutor.query.all()
        for j in tutor_account:
            tutor_id = j.tutor_id_num
            for i in admin_account:
                admin_id = i.admin_id_num
                if tutor_id == tutor_login_form.id_num.data:
                    tutor_info = Tutor.query.filter_by(tutor_id_num=tutor_login_form.id_num.data).first()
                    tutor_pass = tutor_info.tutor_password

                    if tutor_pass == tutor_login_form.password.data:
                        session['user'] = tutor_login_form.id_num.data

                        return redirect(url_for('tutor_retrieve_content'))
                if admin_id == tutor_login_form.id_num.data:
                    admin_info = Admin.query.filter_by(admin_id_num=tutor_login_form.id_num.data).first()
                    admin_pass = admin_info.admin_password

                    if admin_pass == tutor_login_form.password.data:
                        session['user'] = tutor_login_form.id_num.data

                        return redirect(url_for('tutor_retrieve_content'))

    return render_template('tutorlogin.html')


@app.route("/")
def admin_main():
    return render_template('adminMain.html')


@app.route('/createstudent', methods=['GET', 'POST'])
def create_student_account():
    create_student_form = CreateStudentAccount(request.form)
    if request.method == 'POST' and create_student_form.validate():
        with app.app_context():
            db.create_all()

            student_id_num = request.form['student_id_num']
            student_first_name = request.form['student_first_name']
            student_last_name = request.form['student_last_name']
            student_password = request.form['student_password']
            student_mobile = request.form['student_mobile']
            student_email = request.form['student_email']
            student_education_level = request.form['student_education_level']
            student_class = pickle.dumps(create_student_form.student_class.data)

            img = request.files['student_img']
            if img.filename == "":
                student_img = "defaultprofile.jpg"
            else:
                student_img = save_image(img)
            student = Student(student_id_num, student_first_name, student_last_name, student_password, student_mobile, student_email, student_education_level, student_class, student_img)
            db.session.add(student)
            db.session.commit()

        return redirect(url_for('retrieve_student_account'))
    return render_template('createstudent.html', form=create_student_form)


@app.route('/retrievestudent')
def retrieve_student_account():
    if g.user:
        id_num = session['user']
        update_student_account = CreateStudentAccount(request.form)
        with app.app_context():
            student_data = Student.query.all()

            student_education_level = ""
            student_class = ""
            student_class_list = []
            student_class_dict = {}
            for j in student_data:
                student_education_level = j.student_education_level

            for i in student_data:
                student_class_list = i.student_class
                student_id_num = i.student_id_num
                student_class_list = pickle.loads(student_class_list)
                student_class = ', '.join(student_class_list)
                student_class_dict[student_id_num] = student_class

            for k in student_data:
                student_id_num = k.student_id_num
                if student_id_num == id_num:
                    student_name = k.student_first_name + " " + k.student_last_name
                    student_img = k.student_img

        return render_template('retrievestudent.html', count=len(student_data), student=student_data, student_education_level=student_education_level, student_classes=student_class, student_class_list=student_class_list, student_class_dict=student_class_dict, student_nav_name=student_name, student_nav_img=student_img, form=update_student_account)
    return redirect(url_for('student_login'))


@app.route('/updatestudent', methods=['GET', 'POST'])
def update_student_account():
    update_student_form = CreateStudentAccount(request.form)
    if request.method == 'POST' and update_student_form.validate():
        with app.app_context():
            student_data = Student.query.get(request.form.get('student_id_num'))

            student_data.student_id_num = request.form['student_id_num']
            student_data.student_first_name = request.form['student_first_name']
            student_data.student_last_name = request.form['student_last_name']
            student_data.student_password = request.form['student_password']
            student_data.student_mobile = request.form['student_mobile']
            student_data.student_email = request.form['student_email']
            student_data.student_education_level = request.form['student_education_level']
            student_data.student_class = pickle.dumps(update_student_form.student_class.data)

            db.session.commit()
            return redirect(url_for('retrieve_student_account'))


@app.route('/deletestudent/<string:student_id_num>', methods=['POST'])
def delete_student_account(student_id_num):
    student_data = Student.query.get(student_id_num)

    student_img = student_data.student_img
    if student_img != 'defaultprofile.jpg':
        os.remove(os.path.join(app.root_path, 'static/profile_pics', student_img))

    db.session.delete(student_data)
    db.session.commit()

    return redirect(url_for('retrieve_student_account'))


@app.route('/createtutor', methods=['GET', 'POST'])
def create_tutor_account():
        create_tutor_form = CreateTutorAccount(request.form)
        if request.method == 'POST' and create_tutor_form.validate():
            with app.app_context():
                db.create_all()

                tutor_id_num = request.form['tutor_id_num']
                tutor_first_name = request.form['tutor_first_name']
                tutor_last_name = request.form['tutor_last_name']
                tutor_password = request.form['tutor_password']
                tutor_age = request.form['tutor_age']
                tutor_mobile = request.form['tutor_mobile']
                tutor_email = request.form['tutor_email']
                tutor_teaching_level = pickle.dumps(create_tutor_form.tutor_teaching_level.data)
                tutor_class = pickle.dumps(create_tutor_form.tutor_class.data)

                img = request.files['tutor_img']
                if img.filename == "":
                    tutor_img = "defaultprofile.jpg"
                else:
                    tutor_img = save_image(img)
                
                tutor = Tutor(tutor_id_num, tutor_first_name, tutor_last_name, tutor_password, tutor_age, tutor_mobile, tutor_email, tutor_teaching_level, tutor_class, tutor_img)
                db.session.add(tutor)
                db.session.commit()

            return redirect(url_for('retrieve_tutor_account'))
        return render_template('createtutor.html', form=create_tutor_form)


@app.route('/retrievetutor')
def retrieve_tutor_account():
        update_tutor_form = CreateTutorAccount(request.form)
        with app.app_context():
            tutor_data = Tutor.query.all()

            tutor_teach = ""
            tutor_teaching_level = ""
            tutor_class = ""
            tutor_class_list = []
            tutor_level_dict = {}
            tutor_class_dict = {}
            for j in tutor_data:
                tutor_teaching_level = j.tutor_teaching_level
                tutor_id_num = j.tutor_id_num
                tutor_teaching_level = pickle.loads(tutor_teaching_level)
                tutor_teach = ', '.join(tutor_teaching_level)
                tutor_level_dict[tutor_id_num] = tutor_teach

            for i in tutor_data:
                tutor_class_list = i.tutor_class
                tutor_id_num = i.tutor_id_num
                tutor_class_list = pickle.loads(tutor_class_list)
                tutor_class = ', '.join(tutor_class_list)
                tutor_class_dict[tutor_id_num] = tutor_class

        return render_template('retrievetutor.html', count=len(tutor_data), tutor=tutor_data, tutor_teaching=tutor_teach, tutor_teaching_level=tutor_teaching_level, tutor_classes=tutor_class, tutor_class_list=tutor_class_list, tutor_level_dict=tutor_level_dict, tutor_class_dict=tutor_class_dict, form=update_tutor_form)


@app.route('/updatetutor', methods=['GET', 'POST'])
def update_tutor_account():
    update_tutor_form = CreateTutorAccount(request.form)
    if request.method == 'POST' and update_tutor_form.validate():
        with app.app_context():
            tutor_data = Tutor.query.get(request.form.get('tutor_id_num'))

            tutor_data.tutor_id_num = request.form['tutor_id_num']
            tutor_data.tutor_first_name = request.form['tutor_first_name']
            tutor_data.tutor_last_name = request.form['tutor_last_name']
            tutor_data.tutor_password = request.form['tutor_password']
            tutor_data.tutor_age = request.form['tutor_age']
            tutor_data.tutor_mobile = request.form['tutor_mobile']
            tutor_data.tutor_email = request.form['tutor_email']
            tutor_data.tutor_teaching_level = pickle.dumps(update_tutor_form.tutor_teaching_level.data)
            tutor_data.tutor_class = pickle.dumps(update_tutor_form.tutor_class.data)

            db.session.commit()
            return redirect(url_for('retrieve_tutor_account'))


@app.route('/deletetutor/<string:tutor_id_num>', methods=['POST'])
def delete_tutor_account(tutor_id_num):
    tutor_data = Tutor.query.get(tutor_id_num)
    
    tutor_img = tutor_data.tutor_img
    if tutor_img != 'defaultprofile.jpg':
        os.remove(os.path.join(app.root_path, 'static/profile_pics', tutor_img))
    
    db.session.delete(tutor_data)
    db.session.commit()

    return redirect(url_for('retrieve_tutor_account'))


@app.route('/createNotification', methods=['GET', 'POST'])
def create_notification():
    create_notification_form = CreateNotifications(request.form)
    if request.method == 'POST' and create_notification_form.validate():
        notification_dict = {}
        db = shelve.open('notification.db', 'c')

        try:
            notification_dict = db['Notification']
        except:
            print("Error in retrieving Notifications from Database")

        date = datetime.now()
        notification = Notification.Notification(date, create_notification_form.title.data, create_notification_form.description.data)
        notification_dict[notification.get_notif_id()] = notification
        db['Notification'] = notification_dict

        db.close()

        return redirect(url_for('tutor_login'))
    return render_template('createNotification.html', form=create_notification_form)


@app.route('/retrieveNotification')
def retrieve_notification():
    notification_dict = {}
    db = shelve.open('notification.db', 'r')
    notification_dict = db['Notification']
    db.close()

    notification_list = []
    for key in notification_dict:
        notif = notification_dict.get(key)
        notification_list.append(notif)

    return render_template('retrieveNotification.html', count=len(notification_list), notification_list=notification_list)


@app.route('/updateNotification/<int:notif_id>/', methods=['GET', 'POST'])
def update_notification(notif_id):
    update_notification_form = CreateNotifications(request.form)
    if request.method == 'POST' and update_notification_form.validate():
        notification_dict = {}
        db = shelve.open('notification.db', 'w')
        notification_dict = db['Notification']

        notif = notification_dict.get(notif_id)
        notif.set_title(update_notification_form.title.data)
        notif.set_description(update_notification_form.description.data)

        db['Notification'] = notification_dict
        db.close()

        return redirect(url_for('retrieve_notification'))
    else:
        notification_dict = {}
        db = shelve.open('notification.db', 'r')
        notification_dict = db['Notification']
        db.close()

        notif = notification_dict.get(notif_id)
        update_notification_form.title.data = notif.get_title()
        update_notification_form.description.data = notif.description()

    return render_template('updateNotification.html', form=update_notification_form)


@app.route('/deleteNotification/<int:notif_id>', methods=['POST'])
def delete_notification(notif_id):
    notification_dict = {}
    db = shelve.open('notification.db', 'w')
    notification_dict = db['Notification']

    notification_dict.pop(notif_id)

    db['Notification'] = notification_dict
    db.close()

    return redirect(url_for('retrieve_notification'))


# ------------------ GOH CHOON MENG, JEREN ----------------
@app.route('/createTest', methods=['GET', 'POST'])
def create_tests():
    create_test_question = CreateTestQuestion(request.form)
    if request.method == 'POST' and create_test_question.validate():
        tests_dict = {}
        db = shelve.open('content.db', 'c')
        try:
            tests_dict = db['Tests']
        except:
            print("Error in retrieving test from test.db.")
        test = Test.Test(create_test_question.content_id.data, create_test_question.content_subject.data, create_test_question.marks.data, create_test_question.q1.data, create_test_question.a1.data, create_test_question.q2.data, create_test_question.a2.data, create_test_question.q3.data, create_test_question.a3.data)
        tests_dict[test.get_content_id()] = test
        db['Tests'] = tests_dict

        db.close()
        return redirect(url_for('tutor_retrieve_content'))
    return render_template('TutorCreateTest.html', form=create_test_question)


@app.route('/createRevision', methods=['GET', 'POST'])
def create_revisions():
    create_revision_question = CreateRevisionQuestion(request.form)
    if request.method == 'POST' and create_revision_question.validate():
        revisions_dict = {}
        db = shelve.open('content.db', 'c')
        try:
            revisions_dict = db['Revisions']
        except:
            print("Error in retrieving revision from content.db.")
        revision = Revision.Revision(create_revision_question.content_id.data, create_revision_question.content_subject.data, create_revision_question.marks.data, create_revision_question.q1.data, create_revision_question.a1.data, create_revision_question.q2.data, create_revision_question.a2.data, create_revision_question.q3.data, create_revision_question.a3.data)
        revisions_dict[revision.get_content_id()] = revision
        db['Revisions'] = revisions_dict

        db.close()
        return redirect(url_for('tutor_retrieve_content'))
    return render_template('TutorCreateRevision.html', form=create_revision_question)


@app.route('/updateTest/<string:id>/', methods=['GET', 'POST'])
def update_test(id):
    update_test_question = CreateTestQuestion(request.form)
    if request.method == 'POST' and update_test_question.validate():
        tests_dict = {}
        db = shelve.open('content.db', 'w')
        tests_dict = db['Tests']

        test = tests_dict.get(id)
        test.set_content_id(update_test_question.content_id.data)
        test.set_content_subject(update_test_question.content_subject.data)
        test.set_marks(update_test_question.marks.data)
        test.set_q1(update_test_question.q1.data)
        test.set_a1(update_test_question.a1.data)
        test.set_q2(update_test_question.q2.data)
        test.set_a2(update_test_question.a2.data)
        test.set_q3(update_test_question.q3.data)
        test.set_a3(update_test_question.a3.data)

        db['Tests'] = tests_dict
        db.close()

        return redirect(url_for('tutor_retrieve_content'))
    else:
        tests_dict = {}
        db = shelve.open('content.db', 'r')
        tests_dict = db['Tests']
        db.close()

        test = tests_dict.get(id)
        update_test_question.content_id.data = test.get_content_id()
        update_test_question.content_subject.data = test.get_content_subject()
        update_test_question.marks.data = test.get_marks()
        update_test_question.q1.data = test.get_q1()
        update_test_question.a1.data = test.get_a1()
        update_test_question.q2.data = test.get_q2()
        update_test_question.a2.data = test.get_a2()
        update_test_question.q3.data = test.get_q3()
        update_test_question.a3.data = test.get_a3()

        return render_template('TutorUpdateTest.html', form=update_test_question)


@app.route('/updateRevision/<string:id>/', methods=['GET', 'POST'])
def update_revision(id):
    update_revision_question = CreateRevisionQuestion(request.form)
    if request.method == 'POST' and update_revision_question.validate():
        revisions_dict = {}
        db = shelve.open('content.db', 'w')
        revisions_dict = db['Revisions']

        revision = revisions_dict.get(id)
        revision.set_content_id(update_revision_question.content_id.data)
        revision.set_content_subject(update_revision_question.content_subject.data)
        revision.set_marks(update_revision_question.marks.data)
        revision.set_q1(update_revision_question.q1.data)
        revision.set_a1(update_revision_question.a1.data)
        revision.set_q2(update_revision_question.q2.data)
        revision.set_a2(update_revision_question.a2.data)
        revision.set_q3(update_revision_question.q3.data)
        revision.set_a3(update_revision_question.a3.data)

        db['Revisions'] = revisions_dict
        db.close()

        return redirect(url_for('tutor_retrieve_content'))
    else:
        tests_dict = {}
        db = shelve.open('content.db', 'r')
        revisions_dict = db['Revisions']
        db.close()

        revision = revisions_dict.get(id)
        update_revision_question.content_id.data = revision.get_content_id()
        update_revision_question.content_subject.data = revision.get_content_subject()
        update_revision_question.marks.data = revision.get_marks()
        update_revision_question.q1.data = revision.get_q1()
        update_revision_question.a1.data = revision.get_a1()
        update_revision_question.q2.data = revision.get_q2()
        update_revision_question.a2.data = revision.get_a2()
        update_revision_question.q3.data = revision.get_q3()
        update_revision_question.a3.data = revision.get_a3()

        return render_template('TutorUpdateRevision.html', form=update_revision_question)


@app.route('/deleteTest/<string:id>', methods=['POST'])
def delete_test(id):
    tests_dict = {}
    db = shelve.open('content.db', 'w')
    tests_dict = db['Tests']

    tests_dict.pop(id)

    db['Tests'] = tests_dict
    db.close()

    return redirect(url_for('tutor_retrieve_content'))


@app.route('/deleteRevision/<string:id>', methods=['POST'])
def delete_revision(id):
    tests_dict = {}
    db = shelve.open('content.db', 'w')
    revisions_dict = db['Revisions']

    revisions_dict.pop(id)

    db['Revisions'] = revisions_dict
    db.close()

    return redirect(url_for('tutor_retrieve_content'))


@app.route('/studentTestQuestion/<string:id>/', methods=['GET', 'POST'])
def student_test_question(id):
    tests_dict = {}
    db = shelve.open('content.db', 'r')
    tests_dict = db['Tests']
    db.close()

    tests_list = []
    count_marks = 0
    for key in tests_dict:
        if key == id:
            tests = tests_dict.get(key)
            tests_list.append(tests)
            break
        else:
            print("Error")

    student_test_question = StudentTestQuestion(request.form)
    if request.method == 'POST':
        s_tests_dict = {}
        db = shelve.open('student.db', 'c')
        try:
            s_tests_dict = db['Tests']
        except:
            print("Error in retrieving test from test.db.")
        test = STEST.STest(student_test_question.content_id.data, student_test_question.content_subject.data, student_test_question.a1.data, student_test_question.a2.data, student_test_question.a3.data)
        s_tests_dict[test.get_content_id()] = test
        db['Tests'] = s_tests_dict
        db.close()

        l1 = []
        l2 = []
        for key in tests_dict:
            if key == id:
                test = tests_dict.get(key)
                l1.append(test)

        for key in s_tests_dict:
            student_test = s_tests_dict.get(key)
            l2.append(student_test)

        for i in l1:
            a1 = i.get_a1()
            a2 = i.get_a2()
            a3 = i.get_a3()
            for j in l2:
                sa1 = j.get_a1()
                sa2 = j.get_a2()
                sa3 = j.get_a3()
                if a1 == sa1:
                    count_marks += 1
                if a2 == sa2:
                    count_marks += 1
                if a3 == sa3:
                    count_marks += 1

        marks_dict = {}
        db = shelve.open('content.db', 'w')
        try:
            marks_dict = db['Tests']
        except:
            print('error retrieving test marks')

        test = marks_dict.get(id)
        test.set_marks(count_marks)
        print(count_marks)
        db['Tests'] = marks_dict
        db.close()

        return redirect(url_for('retrieve_content'))
    return render_template('StudentTest.html', tests_list=tests_list, form=student_test_question)


@app.route('/studentRevisionQuestion/<string:id>/', methods=['GET', 'POST'])
def student_revision_question(id):
    revisions_dict = {}
    db = shelve.open('content.db', 'r')
    revisions_dict = db['Revisions']
    db.close()

    revisions_list = []
    count_marks = 0
    for key in revisions_dict:
        if key == id:
            revisions = revisions_dict.get(key)
            revisions_list.append(revisions)
            break
        else:
            print("Error")

    student_revision_question = StudentRevisionQuestion(request.form)
    if request.method == 'POST':
        s_revisions_dict = {}
        db = shelve.open('student.db', 'c')
        try:
            s_revisions_dict = db['Revisions']
        except:
            print("Error in retrieving revision from revision.db.")
        revision = SREVISION.SRevision(student_revision_question.content_id.data, student_revision_question.content_subject.data, student_revision_question.a1.data, student_revision_question.a2.data, student_revision_question.a3.data)
        s_revisions_dict[revision.get_content_id()] = revision
        db['Revisions'] = s_revisions_dict
        db.close()

        l3 = []
        l4 = []
        for key in revisions_dict:
            if key == id:
                revision = revisions_dict.get(key)
                l3.append(revision)

        for key in s_revisions_dict:
            student_revision = s_revisions_dict.get(key)
            l4.append(student_revision)

        for i in l3:
            a1 = i.get_a1()
            a2 = i.get_a2()
            a3 = i.get_a3()
            for j in l4:
                sa1 = j.get_a1()
                sa2 = j.get_a2()
                sa3 = j.get_a3()
                if a1 == sa1:
                    count_marks += 1
                if a2 == sa2:
                    count_marks += 1
                if a3 == sa3:
                    count_marks += 1

        marks_dict = {}
        db = shelve.open('content.db', 'w')
        try:
            marks_dict = db['Revisions']
        except:
            print('error retrieving revision marks')

        revision = marks_dict.get(id)
        revision.set_marks(count_marks)
        print(count_marks)
        db['Revisions'] = marks_dict
        db.close()

        return redirect(url_for('retrieve_content'))
    return render_template('StudentRevision.html', revisions_list=revisions_list, form=student_revision_question)


@app.route('/StudentRetrieveContent')
def retrieve_content():
    tests_dict = {}
    db = shelve.open('content.db', 'r')
    tests_dict = db['Tests']
    db.close()

    tests_list = []
    for key in tests_dict:
        test = tests_dict.get(key)
        tests_list.append(test)

    revisions_dict = {}
    db = shelve.open('content.db', 'r')
    revisions_dict = db['Revisions']
    db.close()

    revisions_list = []
    for key in revisions_dict:
        revision = revisions_dict.get(key)
        revisions_list.append(revision)

    return render_template('StudentRetrieveContent.html', test_count=len(tests_list), tests_list=tests_list, revision_count=len(revisions_list), revisions_list=revisions_list)


@app.route('/TutorRetrieveContent')
def tutor_retrieve_content():

    tests_dict = {}
    db = shelve.open('content.db', 'r')
    tests_dict = db['Tests']
    db.close()

    tests_list = []
    for key in tests_dict:
        test = tests_dict.get(key)
        tests_list.append(test)

    revisions_dict = {}
    db = shelve.open('content.db', 'r')
    revisions_dict = db['Revisions']
    db.close()

    revisions_list = []
    for key in revisions_dict:
        revision = revisions_dict.get(key)
        revisions_list.append(revision)

    return render_template('TutorRetrieveContent.html', count=len(revisions_list), revisions_list=revisions_list, count_test=len(tests_list), tests_list=tests_list)


# ----------------- JIANG ANDI ----------------
@app.route('/createFeedback', methods=['GET', 'POST'])
def create_feedback_form():
    if g.user:
        name = ""
        id_num = session['user']

        if id_num[0] == 'S' and inspector.has_table("student"):
            student_account = Student.query.all()
            for i in student_account:
                student_id = i.student_id_num
                if id_num == student_id:
                    student_info = Student.query.filter_by(student_id_num=id_num).first()
                    first_name = student_info.student_first_name
                    last_name = student_info.student_last_name
                    name = first_name + " " + last_name
        elif id_num[0] == 'T' and inspector.has_table("tutor"):
            tutor_account = Tutor.query.all()
            for i in tutor_account:
                tutor_id = i.tutor_id_num
                if id_num == tutor_id:
                    tutor_info = Tutor.query.filter_by(tutor_id_num=id_num).first()
                    first_name = tutor_info.tutor_first_name
                    last_name = tutor_info.tutor_last_name
                    name = first_name + " " + last_name

        else:
            name = None

        create_feedback_form = CreateFeedback(request.form)
        if request.method == 'POST' and create_feedback_form.validate():
            feedback_dict = {}
            db = shelve.open('Feedback.db', 'c')
            try:
                feedback_dict = db['Feedback']
                Feedback.count_id= db['Feedback_feedback_id']

            except:
                print("Error in retrieving Feedback from Feedback.db.")
                db['Feedback'] = feedback_dict

            feedback = Feedback(
                id_num,
                create_feedback_form.feedback_subject.data,
                create_feedback_form.feedback_title.data,
                create_feedback_form.feedback_description.data,
                create_feedback_form.feedback_comment.data,
                name,
                create_feedback_form.feedback_date.data)
            feedback_dict[feedback.get_feedback_id()] = feedback
            db['Feedback'] = feedback_dict
            db['Feedback_feedback_id'] = Feedback.count_id
            db.close()
            return redirect(url_for('retrieve_feedback_form'))
        return render_template('createFeedback.html', form=create_feedback_form)
    return redirect(url_for('tutor_login'))


@app.route('/createFeedback2', methods=['GET', 'POST'])
def create_feedback_form2():
    if g.user:
        name = ""
        id_num = session['user']

        if id_num[0] == 'S' and inspector.has_table("student"):
            student_account = Student.query.all()
            for i in student_account:
                student_id = i.student_id_num
                if id_num == student_id:
                    student_info = Student.query.filter_by(student_id_num=id_num).first()
                    first_name = student_info.student_first_name
                    last_name = student_info.student_last_name
                    name = first_name + " " + last_name
        elif id_num[0] == 'T' and inspector.has_table("tutor"):
            tutor_account = Tutor.query.all()
            for i in tutor_account:
                tutor_id = i.tutor_id_num
                if id_num == tutor_id:
                    tutor_info = Tutor.query.filter_by(tutor_id_num=id_num).first()
                    first_name = tutor_info.tutor_first_name
                    last_name = tutor_info.tutor_last_name
                    name = first_name + " " + last_name
        else:
            name = None

        create_feedback_form = CreateFeedback(request.form)
        if request.method == 'POST' and create_feedback_form.validate():
            feedback_dict = {}
            db = shelve.open('Feedback.db', 'c')
            try:
                feedback_dict = db['Feedback']
                Feedback.count_id= db['Feedback_feedback_id']

            except:
                print("Error in retrieving Feedback from Feedback.db.")
                db['Feedback'] = feedback_dict

            feedback = Feedback(
                id_num,
                create_feedback_form.feedback_subject.data,
                create_feedback_form.feedback_title.data,
                create_feedback_form.feedback_description.data,
                create_feedback_form.feedback_comment.data,
                name,
                create_feedback_form.feedback_date.data)
            feedback_dict[feedback.get_feedback_id()] = feedback
            db['Feedback'] = feedback_dict
            db['Feedback_feedback_id'] = Feedback.count_id
            db.close()
            return redirect(url_for('retrieve_feedback_form2'))
        return render_template('createFeedback.html', form=create_feedback_form)
    return redirect(url_for('student_login'))


@app.route('/retrieveFeedback')
def retrieve_feedback_form():
    feedback_dict = {}
    db = shelve.open('Feedback.db', 'r')
    feedback_dict = db['Feedback']
    db.close()

    feedback_list = []
    for key in feedback_dict:
        feedback = feedback_dict.get(key)
        feedback_list.append(feedback)

    return render_template('retrieveFeedback.html', count=len(feedback_list), feedback_list=feedback_list)


@app.route('/retrieveFeedbackView')
def retrieve_feedback_form2():
    if g.user:
        id_num = session['user']
        feedback_dict = {}
        db = shelve.open('Feedback.db', 'r')
        feedback_dict = db['Feedback']
        db.close()

        name_list = []
        tutor_account = Tutor.query.all()
        for i in tutor_account:
            tutor_id = i.tutor_id_num
            if tutor_id == id_num:
                details = Tutor.query.filter_by(tutor_id_num=id_num).first()
                name_list.append(details)

        feedback_list = []
        admin_account = []
        for key in feedback_dict:
            feedback = feedback_dict.get(key)
            if feedback.get_feedback_adminid() == id_num:
                feedback_list.append(feedback)
            else:
                admin = feedback_dict.get(key)
                admin_account.append(admin)

        return render_template('retrieveFeedback_view.html', count=len(feedback_list), feedback_list=feedback_list, user=session['user'], name_list=name_list)
    return redirect(url_for('student_login'))


@app.route('/updateFeedback/<int:id>/', methods=['GET', 'POST'])
def update_feedback(id):
    update_feedback_form = CreateFeedback(request.form)
    if request.method == 'POST' and update_feedback_form.validate():
        feedback_dict = {}
        db = shelve.open('Feedback.db', 'w')
        feedback_dict = db['Feedback']
        feedback = feedback_dict.get(id)
        feedback.set_feedback_subject(update_feedback_form.feedback_subject.data)
        feedback.set_feedback_title(update_feedback_form.feedback_title.data)
        feedback.set_feedback_description(update_feedback_form.feedback_description.data)
        feedback.set_feedback_comment(update_feedback_form.feedback_comment.data)
        feedback.set_feedback_date(update_feedback_form.feedback_date.data)
        db['Feedback'] = feedback_dict
        db.close()
        return redirect(url_for('retrieve_feedback_form'))
    else:
        feedback_dict = {}
        db = shelve.open('Feedback.db', 'r')
        feedback_dict = db['Feedback']
        db.close()
        feedback = feedback_dict.get(id)
        update_feedback_form.feedback_subject.data = feedback.get_feedback_subject()
        update_feedback_form.feedback_title.data = feedback.get_feedback_title()
        update_feedback_form.feedback_description.data = feedback.get_feedback_description()
        update_feedback_form.feedback_comment.data = feedback.get_feedback_comment()
        update_feedback_form.feedback_date.data = feedback.get_feedback_date()
        return render_template('updateFeedback.html', form=update_feedback_form)


@app.route('/deleteFeedback/<int:id>', methods=['POST'])
def delete_feedback(id):
    feedback_dict = {}
    db = shelve.open('Feedback.db', 'w')
    feedback_dict = db['Feedback']
    feedback_dict.pop(id)
    db['Feedback'] = feedback_dict
    db.close()
    return redirect(url_for('retrieve_feedback_form'))


# ----------------- EZEKKIOUS ----------------
@app.route('/createAnnouncements', methods=['GET', 'POST'])
def create_announcement():
    if g.user:
        id_num = session['user']
        create_announcement_form = CreateAnnouncementForm(request.form)
        tutor_list = []
        if request.method == 'POST' and create_announcement_form.validate():
            ann_dict = {}
            db = shelve.open('announcement.db', 'c')

            try:
                ann_dict = db['announce']
                Announcement.count_id = db['announce_id']
            except:
                print('lol')
                db['announce'] = ann_dict
            date1 = datetime.now()
            adate = date1.strftime("%A, %d %B %Y %I:%M%p")
            announcement = announce.Announcement(id_num, adate, create_announcement_form.atitle.data, create_announcement_form.acontent.data, create_announcement_form.afiles.data)
            ann_dict[announcement.get_ann_id()] = announcement
            db['announce'] = ann_dict
            db['announce_id'] = Announcement.count_id
            db.close()

            return redirect(url_for('retrieve_announcement'))
        print('zzz')
        return render_template('createAnnouncements.html', form=create_announcement_form, tutor_list=tutor_list)
    return redirect(url_for('tutor_login'))


@app.route('/retrieveAnnouncements')
def retrieve_announcement():
    ann_dict = {}
    db = shelve.open('announcement.db', 'r')
    ann_dict = db['announce']
    db.close()

    ann_list = []
    for key in ann_dict:
        announcement = ann_dict.get(key)
        ann_list.append(announcement)

    return render_template('retrieveAnnouncements.html', count=len(ann_list), ann_list=ann_list)


@app.route('/editAnnouncements/<int:id>/', methods=['GET', 'POST'])
def edit_announcement(id):
    edit_announcement_form = CreateAnnouncementForm(request.form)
    if request.method == 'POST' and edit_announcement_form.validate():
        ann_dict = {}
        db = shelve.open('announcement.db', 'w')
        ann_dict = db['announce']
        announcement = ann_dict.get(id)
        announcement.set_title(edit_announcement_form.atitle.data)
        announcement.set_content(edit_announcement_form.acontent.data)
        db['announce'] = ann_dict
        db.close()
        return redirect(url_for('retrieve_announcement'))
    else:
        ann_dict = {}
        db = shelve.open('announcement.db', 'r')
        ann_dict = db['announce']
        db.close()

        announcement = ann_dict.get(id)
        edit_announcement_form.atitle.data = announcement.get_title()
        edit_announcement_form.acontent.data = announcement.get_content()

    return render_template('editAnnouncements.html', form=edit_announcement_form)


@app.route('/deleteAnnouncements/<int:id>', methods=['POST'])
def delete_announcement(id):
    ann_dict = {}
    db = shelve.open('announcement.db', 'w')
    ann_dict = db['announce']
    ann_dict.pop(id)
    db['announce'] = ann_dict
    db.close()
    return redirect(url_for('retrieve_announcement'))


@app.route('/dropsession')
def drop_session():
    session.pop('user', None)
    return render_template('main.html')


if __name__ == '__main__':
    app.run(debug=True)
