from Test import Test


class Revision(Test):
    def __init__(self, content_id, content_subject, marks, q1, a1, q2, a2, q3, a3):
        super().__init__(content_id, content_subject, marks, q1, a1, q2, a2, q3, a3)
