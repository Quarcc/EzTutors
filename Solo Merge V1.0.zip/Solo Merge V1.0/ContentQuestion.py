from wtforms import Form, StringField, RadioField, SelectField, TextAreaField, validators, HiddenField


class CreateTestQuestion(Form):
    content_id = StringField('Test Paper Number', [validators.Length(min=1, max=150), validators.DataRequired()])
    content_subject = StringField('Subject', [validators.Length(min=1, max=150), validators.DataRequired()])
    q1 = StringField("Question 1", [validators.length(min=1), validators.DataRequired()])
    a1 = StringField("Question 1 Answer", [validators.length(min=1), validators.DataRequired()])
    q2 = StringField("Question 2", [validators.length(min=1), validators.DataRequired()])
    a2 = StringField("Question 2 Answer", [validators.length(min=1), validators.DataRequired()])
    q3 = StringField("Question 3", [validators.length(min=1), validators.DataRequired()])
    a3 = StringField("Question 3 Answer", [validators.length(min=1), validators.DataRequired()])


class CreateRevisionQuestion(Form):
    content_id = StringField('Revision Paper Number', [validators.Length(min=1, max=150), validators.DataRequired()])
    content_subject = StringField('Subject', [validators.Length(min=1, max=150), validators.DataRequired()])
    q1 = StringField("Question 1", [validators.length(min=1), validators.DataRequired()])
    a1 = StringField("Question 1 Answer", [validators.length(min=1), validators.DataRequired()])
    q2 = StringField("Question 2", [validators.length(min=1), validators.DataRequired()])
    a2 = StringField("Question 2 Answer", [validators.length(min=1), validators.DataRequired()])
    q3 = StringField("Question 3", [validators.length(min=1), validators.DataRequired()])
    a3 = StringField("Question 3 Answer", [validators.length(min=1), validators.DataRequired()])

#
# class StudentTestQuestion(Form):
#     content_id = HiddenField('Revision Paper Number', [validators.Length(min=1, max=150), validators.DataRequired()])
#     content_subject = HiddenField('Subject', [validators.Length(min=1, max=150), validators.DataRequired()])
#     q1 = HiddenField("Question 1", [validators.length(min=1), validators.DataRequired()])
#     a1 = StringField("Question 1 Answer", [validators.length(min=1), validators.DataRequired()])
#     q2 = HiddenField("Question 2", [validators.length(min=1), validators.DataRequired()])
#     a2 = StringField("Question 2 Answer", [validators.length(min=1), validators.DataRequired()])
#     q3 = HiddenField("Question 3", [validators.length(min=1), validators.DataRequired()])
#     a3 = StringField("Question 3 Answer", [validators.length(min=1), validators.DataRequired()])
